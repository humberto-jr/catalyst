#pragma once

#include <petscviewer.h>
#include <petscvec.h>

PETSC_EXTERN PetscErrorCode VecView_GLVis(Vec, PetscViewer);
